package base.test;

/**
 * Created by shichen.ma on 2017/8/18.
 */
public interface TestInterface {
    public   static final String name = "name";
    public static String age = "age";
    public final String sex = "sex";
    String sex_ = "1";
    String class_ = "classs";
    public abstract void delete();
     void se(String a,String b);
}
