package base.test;

/**
 * Created by shichen.ma on 2017/8/21.
 */
public abstract class TestInterface_abstract implements  TestInterface{
    public void delete() {
        System.out.println("delete");
    }

}
