package base.test;

import java.io.*;

/**
 * Created by shichen.ma on 2017/8/21.
 */
public class Test_Stream {
    public static void main(String[] args) throws IOException {
//        DataOutputStream dos = new DataOutputStream();
//        dos.flush();
//
//        FileOutputStream fos = new FileOutputStream();
//        fos.flush();
//        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//        byteArrayOutputStream.flush();

    }
}
