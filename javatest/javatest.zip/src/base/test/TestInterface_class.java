package base.test;

/**
 * Created by shichen.ma on 2017/8/21.
 */
public  class TestInterface_class implements  TestInterface{
    public void delete() {
        System.out.println("delete");
    }

    @Override
    public void se(String a, String b) {

    }

    public void se(String a, int b) {

    }

}
