package com.reflect.interf;

/**
 * ${DESCRIPTION}
 *
 * @author masc
 * @create 2017.03.15 15:31
 */
public interface China {
    public static final String name = "Rollen";
    public static int age = 20;
    public void sayChina();
    public void sayHello(String name, int age);
}
