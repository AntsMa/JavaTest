package com.thread2.demo3;

/**
 * ${DESCRIPTION}
 *
 * @author masc
 * @create 2017.06.14 17:01
 */
public class s {


    private String s ="";

    public void main(String[] args) {
        System.out.println(4|3);

        String a ="";
        s.length();
    }
}
