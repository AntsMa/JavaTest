package com.proxy.proxy3;

public interface Humen{

    void eat(String food);
}

