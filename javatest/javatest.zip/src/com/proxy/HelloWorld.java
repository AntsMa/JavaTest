package com.proxy;
/**
* 定义一个HelloWorld接口
* 
* @author jiqinlin
*
*/
public interface HelloWorld {
   public void sayHelloWorld();
}