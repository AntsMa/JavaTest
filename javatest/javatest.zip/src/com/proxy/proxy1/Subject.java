package com.proxy.proxy1;

public interface Subject
{
    public void doSomething();
}
