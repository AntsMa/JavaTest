package com.proxy.cglib;

public interface UserService {
    public String getName(String name,int num);

    public Integer getAge(int id,int num);
}