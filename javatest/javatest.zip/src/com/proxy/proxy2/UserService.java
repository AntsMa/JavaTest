package com.proxy.proxy2;

public interface UserService {
    public String getName(String name);

    public Integer getAge(int id);
}