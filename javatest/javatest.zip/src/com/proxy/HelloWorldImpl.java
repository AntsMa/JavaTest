package com.proxy;
/**
 * 类HelloWorldImpl是HelloWorld接口的实现
 * 
 * @author jiqinlin
 *
 */
 public class HelloWorldImpl implements HelloWorld{

    public void sayHelloWorld() {
        System.out.println("HelloWorld!");
    }

}