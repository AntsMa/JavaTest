package com.proxy;
/**
* 定义一个HelloWorld接口
* 
* @author jiqinlin
*
*/
public interface Copy_2_of_HelloWorld {
   public void sayHelloWorld();
}