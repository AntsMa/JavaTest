package com.collection;

/**
 * ${DESCRIPTION}
 *
 * @author masc
 * @create 2017.03.22 22:55
 */
public class Student {
    int score;

    public Student(int score){
        this.score = score;
    }

    public String toString(){
        return String.valueOf(this.score);
    }
}
