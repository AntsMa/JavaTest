package com.collection;

import java.util.Comparator;

class MyComparator_2 implements Comparable<String> {
    @Override
    public int compareTo(String o) {
        return 0;
    }


}