package com.chen2;
/**  
 * Copyright: Copyright (c) 2016 Asiainfo
 * 
 * @ClassName: stu.java
 * @Description: 该类的功能描述
 *
 * @version: v1.0.0
 * @author: masc
 * @date: 2016年4月8日 上午9:41:43 
 *
 * Modification History:
 * Date         Author          Version            Description
 *---------------------------------------------------------*
 */
public class stu {
	private Long id ;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
}
