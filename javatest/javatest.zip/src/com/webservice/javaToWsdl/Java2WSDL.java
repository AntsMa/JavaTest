package com.webservice.javaToWsdl;


import org.apache.cxf.tools.java2ws.JavaToWS;

/**
 * @description 
 * @author zhu_qhua 
 */  
public class Java2WSDL {  
   /* private Class<?> className;
    public String[] args1,args2,args3;  

    public Java2WSDL(Class<?> className) {  
        this.className = className;   
        args1=new String[]{"-wsdl","-d","D:\\softInstall\\workSpace\\integrationCMS\\src\\com\\asiainfo\\um\\adapter\\cms\\java2Wsdl",this.className.getName()};
        args2=new String[]{"-wsdl","-cp", "./example",this.className.getName()};  
        args3=new String[]{"-o","myHello.wsdl","-wsdl",this.className.getName()};  
    }  
    
  
    public void java2WSDL(String[] args){  
        JavaToWS javaToWS = new JavaToWS(args);
        try {  
            javaToWS.run();  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    public static void main(String[] args) {  
        Java2WSDL java2WSDL = new Java2WSDL(HelloWord.class);  
        java2WSDL.java2WSDL(java2WSDL.args1);  
    }*/

}  
