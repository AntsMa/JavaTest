package com.sql;

public class test {
    public static void main(String[] args) {
        int ran = 0 ;
        for (int i =0 ;i<100;i++){
//             ran =(int)(1+Math.random()*10);
//            System.out.println(ran);
            System.out.println(Math.random()*10);
        }
    }
}
