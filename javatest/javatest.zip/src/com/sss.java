package com;
/**  
 * Copyright: Copyright (c) 2016 Asiainfo
 * 
 * @Description: 该类的功能描述
 *
 * @version: v1.0.0
 * @author: masc
 * @date: 2016年5月19日 下午7:37:41 
 *
 * Modification History:
 * Date         Author          Version            Description
 *---------------------------------------------------------*
 */
public class sss {
 private String a ;
}
