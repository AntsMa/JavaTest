package com.chen.test;

import java.util.Date;

/**  
 * Copyright: Copyright (c) 2016 Asiainfo
 * 
 * @ClassName: test1.java
 * @Description: 该类的功能描述
 *
 * @version: v1.0.0
 * @author: masc
 * @date: 2016年2月22日 下午4:34:44 
 *
 * Modification History:
 * Date         Author          Version            Description
 *---------------------------------------------------------*
 */
public class test1 {
public static void main(String[] args) {
	String[] aa = null ;
	aa = new String[1];
	aa[0]= "aa";
	System.out.println(aa[0]);
}
}
